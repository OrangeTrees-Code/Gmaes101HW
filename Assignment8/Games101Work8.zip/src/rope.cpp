#include <iostream>
#include <vector>

#include "CGL/vector2D.h"

#include "mass.h"
#include "rope.h"
#include "spring.h"

namespace CGL {

    Rope::Rope(Vector2D start, Vector2D end, int num_nodes, float node_mass, float k, vector<int> pinned_nodes)
    {
        // TODO (Part 1): Create a rope starting at `start`, ending at `end`, and containing `num_nodes` nodes.
        for (int i = 0; i < num_nodes; ++i)
        {
            auto length = ((end - start) / (end - start).norm()) * ((end - start).norm() / (num_nodes - 1));
            masses.push_back(new Mass(start + i * length, node_mass, false));
            if (i>0)
            {
                springs.push_back(new Spring(masses[i-1], masses[i], k));
            }
        }
        //Comment-in this part when you implement the constructor
        for (auto &i : pinned_nodes) {
            masses[i]->pinned = true;
        }
    }

    void Rope::simulateEuler(float delta_t, Vector2D gravity)
    {
        for (auto &s : springs)
        {
            // TODO (Part 2): Use Hooke's law to calculate the force on a node
            auto& a = s->m1->position;
            auto& b = s->m2->position;
            auto& ks = s->k;
            auto len = (a - b).norm();
            s->m2->forces += -1. * ks * ((b - a) / len) * (len - s->rest_length);
            s->m1->forces += -1. * ks * ((a - b) / len) * (len - s->rest_length);
        }

        for (auto &m : masses)
        {
            if (!m->pinned)
            {
                // TODO (Part 2): Add the force due to gravity, then compute the new velocity and position
                auto& F = m->forces;
                auto& mas = m->mass;
                auto& v = m->velocity;
                m->forces += gravity;

                /*float kd = 0.01f;
                F += -1.f * kd * v;*/

                float damping_factor = 0.0005f;
                auto a = F / mas;
                v = v + a * delta_t;
                v *= (1 - damping_factor);
                m->position = m->last_position + v * delta_t;
                //v = v + a * delta_t;
                m->last_position = m->position;
                
                // TODO (Part 2): Add global damping
            }

            // Reset all forces on each mass
            m->forces = Vector2D(0, 0);
        }
    }

    void Rope::simulateVerlet(float delta_t, Vector2D gravity)
    {
        for (auto &s : springs)
        {
            // TODO (Part 3): Simulate one timestep of the rope using explicit Verlet （solving constraints)
            auto& a = s->m1->position;
            auto& b = s->m2->position;
            auto& ks = s->k;
            auto len = (a - b).norm();
            s->m2->forces += -1. * ks * ((b - a) / len) * (len - s->rest_length);
            s->m1->forces += -1. * ks * ((a - b) / len) * (len - s->rest_length);

            Vector2D dir = s->m2->position - s->m1->position;

            if (len == 0) continue; // 避免除零

            float diff = (len - s->rest_length) / len;
            Vector2D correction = dir * 0.5f * diff;

            if (!s->m1->pinned) s->m1->position += correction;
            if (!s->m2->pinned) s->m2->position -= correction;
        }

        for (auto &m : masses)
        {
            if (!m->pinned)
            {
                m->forces += gravity;
                auto a = m->forces / m->mass;
                Vector2D temp_position = m->position;
                // TODO (Part 3.1): Set the new position of the rope mass
                float damping_factor = 0.0005f;
                m->position = m->position + (1-damping_factor)*(m->position - m->last_position) + a * delta_t * delta_t;
                m->last_position = temp_position;
                // TODO (Part 4): Add global Verlet damping
            }
            m->forces = Vector2D(0, 0);
        }
    }
}
